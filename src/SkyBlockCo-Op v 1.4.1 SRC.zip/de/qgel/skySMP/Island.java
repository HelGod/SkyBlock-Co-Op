package de.qgel.skySMP;

import java.io.Serializable;

public class Island implements Serializable {
	/**
	 * change serialUID if we add anything besides x and z coordinates
	 */
	private static final long serialVersionUID = 1L;
	public int x;
	public int z;
}
